// ============================================================
// CONFIGURACIÓN DE SUPABASE
// ============================================================
// Sustituye estos dos valores con los de tu proyecto Supabase:
// 1. Ve a https://app.supabase.com → tu proyecto
// 2. ⚙️ Project Settings → API
// 3. Copia "Project URL" y "anon public" key
// ============================================================

window.SUPABASE_URL = 'PEGA_AQUI_TU_PROJECT_URL';
window.SUPABASE_ANON_KEY = 'PEGA_AQUI_TU_ANON_KEY';
